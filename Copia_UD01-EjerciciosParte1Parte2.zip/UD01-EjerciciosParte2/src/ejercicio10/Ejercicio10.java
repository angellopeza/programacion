package ejercicio10;

import java.util.Scanner;

public class Ejercicio10 {
	public static void main(String[] args) {
		System.out.println("Año: ");
		Scanner sc = new Scanner(System.in);
		int anyo=sc.nextInt();
		Boolean bis= anyo%400==0 || (anyo%4==0 && anyo%100!=0);
		System.out.println("¿Es bisiesto?: "+ bis);
		sc.close();
	}
}