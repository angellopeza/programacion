package ejercicio14;

import java.util.Scanner;

public class Ejercicio14 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Introduce las notas del 1er trimestre: ");
		int primer= sc.nextInt();
		System.out.println("Introduce las notas del 2o trimestre: ");
		int segun= sc.nextInt();
		System.out.println("Introduce las notas del 3er trimestre: ");
		int tercer= sc.nextInt();
		
		int boletin= (primer+segun+tercer)/3;
		Double expediente= (primer+segun+tercer)/3.0;
		System.out.println("Notas boletin: " + boletin + " Notas expediente: "+ expediente);
		sc.close();
	}
}
