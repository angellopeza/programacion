package ejercicio12;

import java.util.Scanner;

public class Ejercicio12 {
	public static void main(String[] args) {
		System.out.println("Kilos de manzana vendidos: ");
		Scanner sc = new Scanner(System.in);
		int manzanas=sc.nextInt();
		System.out.println("Kilos de peras vendidos: ");
		int peras=sc.nextInt();
		
		double kgMan= (manzanas*2.35);
		double kgPer= (peras*1.95);
		double total= (kgMan+kgPer);
		
		System.out.println("Importe total: " + total + " euros");
		sc.close();
	}
}
