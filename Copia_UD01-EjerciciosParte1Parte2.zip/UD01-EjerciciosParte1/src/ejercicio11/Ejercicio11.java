package ejercicio11;

import java.util.Scanner;

public class Ejercicio11 {
public static void main(String[] args) {
	System.out.println("Introduzca pesetas: ");
	Scanner sc = new Scanner(System.in);
	int pesetas=sc.nextInt();
	int euros= (pesetas/166);
	System.out.println("Las "+ pesetas + " pesetas " + "son " + euros + " euros");
	sc.close();
}
}
