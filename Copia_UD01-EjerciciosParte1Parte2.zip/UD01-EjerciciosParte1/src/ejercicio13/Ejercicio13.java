package ejercicio13;

import java.util.Scanner;

public class Ejercicio13 {
	public static void main(String[] args) {
		System.out.println("¿Esta lloviendo?: ");
		Scanner sc = new Scanner(System.in);
		boolean lluvia=sc.nextBoolean();
		System.out.println("¿Has terminado las tareas?: ");
		boolean tareas=sc.nextBoolean();
		System.out.println("¿Necesitas ir a la biblioteca?: ");
		boolean biblioteca=sc.nextBoolean();
		
		boolean puede= biblioteca==true || (lluvia==false && tareas==true);
		System.out.println("¿Puedes salir?: "+puede);
		sc.close();
	}
}
