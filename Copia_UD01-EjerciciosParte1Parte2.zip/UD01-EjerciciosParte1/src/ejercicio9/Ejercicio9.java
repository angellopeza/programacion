package ejercicio9;

import java.util.Scanner;

public class Ejercicio9 {
	public static void main(String[] args) {
		System.out.println("Introduce tu edad: ");
		Scanner sc = new Scanner(System.in);
		int edad;
		edad=sc.nextInt();
		Boolean mayorEdad = (edad>=18);
		System.out.println("¿Puede entrar?: "+mayorEdad);
		sc.close();
	}
}
