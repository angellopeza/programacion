package ejercicio15;

import java.util.Scanner;

public class Ejercicio15 {
	public static void main(String[] args) {
		System.out.println("Precio sin IVA: ");
		Scanner sc = new Scanner(System.in);
		double precio=sc.nextDouble();
		final Integer IVA=21;
		double precioIVA=precio+(precio*IVA/100);
		System.out.println("El precio con IVA es: "+precioIVA);
		sc.close();

	}
}
