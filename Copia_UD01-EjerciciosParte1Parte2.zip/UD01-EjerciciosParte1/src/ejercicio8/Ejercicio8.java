package ejercicio8;

import java.util.Scanner;

public class Ejercicio8 {
	public static void main(String[] args) {
		System.out.println("Introduce tu nombre: ");
			Scanner sc = new Scanner(System.in);
			String nombre;
			nombre=sc.next();
		System.out.println("Introduce tu edad: ");
			int edad;
			edad=sc.nextInt();
		System.out.println("Hola "+nombre+", tienes "+edad+" ¡Que mayor eres!");
			
		sc.close();
	}
}
