package ejercicio10;

import java.util.Scanner;

public class Ejercicio10 {
	public static void main(String[] args) {
		System.out.println("Introduce un numero: ");
		Scanner sc = new Scanner(System.in);
		int num;
		num=sc.nextInt();
		Boolean imPar = (num%2==0);
		System.out.println("¿El numero es par?: "+ imPar);
		sc.close();
	}
}
